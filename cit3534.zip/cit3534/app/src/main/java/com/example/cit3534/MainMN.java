package com.example.cit3534;

import android.app.ApplicationExitInfo;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainMN  extends AppCompatActivity {

    String u_name="";
    Button save1,show1,set1,outt1;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mainmenu);
        u_name = getIntent().getStringExtra("username");
    }

    public void  exitout(View view)
    {
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("Exit");
        dialog.setIcon(R.mipmap.ic_launcher);
        dialog.setCancelable(true);
        dialog.setMessage("Do you want to exit?");

        dialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });

        dialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        dialog.show();
        finish();


    }

    public  void openseting(View view){

        Toast.makeText(getApplicationContext(),"Setting Page!", Toast.LENGTH_LONG).show();
        Intent intent = new Intent(getApplicationContext(),setting.class);
        startActivity(intent);

    }


}
