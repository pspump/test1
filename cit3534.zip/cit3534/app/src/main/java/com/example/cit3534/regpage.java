package com.example.cit3534;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;

public class regpage extends AppCompatActivity {

    EditText t_user, t_email, t_phone, t_pass;
    String user, email, phone, pass;
    Button resubmit;
    SessionManager sessionManager;

    @Override
    public void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);

        Resources resources = this.getResources ( );

        int resourceID = resources.getIdentifier ( "yutt", "drawable", "com.example.cit3534" );

        ImageView image = ( ImageView ) this.findViewById ( R.id.imgyutt );

        image.setImageResource ( resourceID );

        //----------
        t_user = findViewById(R.id.rename);
        t_email = findViewById(R.id.remail);
        t_phone = findViewById(R.id.rephone);
        t_pass = findViewById(R.id.repass);
    }

    public void ShowWarning(String xMsg) {
        AlertDialog.Builder sbuilder = new AlertDialog.Builder(this);
        sbuilder.setTitle("ALERT");
        sbuilder.setMessage(xMsg);
        sbuilder.setCancelable(false);
        sbuilder.setPositiveButton("OKEY", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {


            }
        });
        AlertDialog selartDialog = sbuilder.create();
        selartDialog.show();

    }

    public void SaveRegister(View view) {

        user = t_user.getText().toString().trim();
        email = t_email.getText().toString().trim();
        phone = t_phone.getText().toString().trim();
        pass = t_pass.getText().toString().trim();


        if (user.equals("")) {
            ShowWarning("Insert Fullname");
            return;
        }
        if (email.equals("")) {
            ShowWarning("Insert email");
            return;
        }
        if (phone.equals("")) {
            ShowWarning("Insert password");
            return;
        }

        if (pass.equals("")) {
            ShowWarning("Insert password");
            return;
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("บันทึกข้อมูล");
        builder.setMessage("ยืนยันข้อมูลครบถ้วนสมบูรณ์?");
        builder.setCancelable(false);
        builder.setPositiveButton("ยืนยัน", new DialogInterface.OnClickListener()

        {
            public void onClick(DialogInterface dialog, int id)
            {
                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
                        .permitAll().build();
                StrictMode.setThreadPolicy(policy);


                StrictMode.setThreadPolicy(policy);

                ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
                sessionManager = new SessionManager(getApplicationContext());
                String URL="";
                URL = "http://"+sessionManager.getIpconfig().toString()+"res3534.php";


                try {

                    nameValuePairs.add(new BasicNameValuePair("username",user));
                    nameValuePairs.add(new BasicNameValuePair("email",email));
                    nameValuePairs.add(new BasicNameValuePair("phone_n",phone));
                    nameValuePairs.add(new BasicNameValuePair("ppassword",pass));


                    // Connect Server


                    HttpClient httpclient = new DefaultHttpClient();
                    //   ShowWarning("4");
                    HttpPost httppost = new HttpPost(URL);
                    ShowWarning(URL);


                    httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));
                    HttpResponse response = httpclient.execute(httppost);
                    int statusCode =  response.getStatusLine().getStatusCode();



                    //Toast.makeText(getApplicationContext(),""+statusCode, Toast.LENGTH_LONG).show();

                    //--------Check status connect

                    if (statusCode == 200) {
                        ShowWarning("บันทึกข้อมูลเรียบร้อย");
                        Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                        startActivity(intent);
                        // finish();

                    } else if (statusCode == 404) {
                        ShowWarning("ขออภัยเกิดวามผิดพลาดในการบันทึกข้อมูล กรุณาตรวจสอบ");

                        return;
                    }
                }

                catch (Exception e) {
                    //  Log.e("TAG", "onClick: ", e);
                    ShowWarning("ขออภัยเกิดวามผิดพลาดกรุณาตรวจสอบ");
                    return;

                }
            }
        })
                .setNegativeButton("เปลี่ยนใจ",new DialogInterface.OnClickListener()
                {
                    public void onClick(DialogInterface dialog, int id)
                    {
                        dialog.cancel();
                        Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);//Clear Activity Stack
                        startActivity(intent);
                        finish();
                    }
                });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();



    }

    public  void backlogin(View view){

        Toast.makeText(getApplicationContext(),"Going to Register!", Toast.LENGTH_LONG).show();
        Intent intent = new Intent(getApplicationContext(),MainActivity.class);
        startActivity(intent);

    }

}
