package com.example.cit3534;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    public SessionManager(Context context){
        sharedPreferences =
                context.getSharedPreferences("user_ID",0);
        editor = sharedPreferences.edit();
        editor.apply();
    }
    //------------------- config ------------------------------
    public String getIpconfig() {

        return "192.168.100.11/api_3534";

    }
    public void setNAME(String NAME){
        editor.putString("username",NAME);
        editor.commit();
    }
   public void setReturnActivity(String page){
        editor.putString("main",page);
        editor.commit();
    }
}

